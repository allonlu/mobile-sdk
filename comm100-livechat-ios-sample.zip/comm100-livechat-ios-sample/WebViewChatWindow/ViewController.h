//
//  ViewController.h
//  WebViewChatWindow
//
//  Created by Allon on 5/14/15.
//  Copyright (c) 2015 Allon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIWebViewDelegate>
{
    IBOutlet UIWebView * webView;
}
@end

