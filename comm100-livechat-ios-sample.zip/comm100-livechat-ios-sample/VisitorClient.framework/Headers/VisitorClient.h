//
//  VisitorClient.h
//  VisitorClient
//
//  Created by Allon on 10/9/15.
//  Copyright © 2015 Comm100. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VisitorClientController.h"

//! Project version number for VisitorClient.
FOUNDATION_EXPORT double VisitorClientVersionNumber;

//! Project version string for VisitorClient.
FOUNDATION_EXPORT const unsigned char VisitorClientVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VisitorClient/PublicHeader.h>


